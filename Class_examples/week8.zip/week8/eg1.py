# The minimum required - but doesn't really do anything

# Best to import like this
import tkinter as tk 

root = tk.Tk()
root.mainloop()
